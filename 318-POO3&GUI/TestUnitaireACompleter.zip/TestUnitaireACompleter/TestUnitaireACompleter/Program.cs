﻿//ETML
//Auteur : JMY  
//Date : 2017
//Description : Résolution d'équation du 2ème degré
using System;

namespace TestUnitaireACompleter
{
    /// <summary>
    /// Démonstration du résolveur d'équation
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //TODO: implémenter une interface d'utilisation en console
        }
    }
}
